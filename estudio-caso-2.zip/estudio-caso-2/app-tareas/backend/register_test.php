<?php
require 'register.php';
echo(userRegistry("juanito2@gmail.com", "123456","juanito2@gmail.com" ));